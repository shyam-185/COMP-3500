#include <stdio.h>
#include <math.h>
#define size 10

int main() 
{
    double array[size];

     printf("Input an array of ten numbers: \n");
    int i = 0;
    for (i = 0; i < size; i++) 
    {
        printf("array[%d]=", i);
        scanf("%lf", &array[i]);
    }
    double sum = 0;
    printf("\nArray = ");
    for (i = 0; i < size; i++) 
    {
        printf("%0.1f, ", array[i]);
        sum += sqrt(array[i]);
    }
    double answer = sum / size;
    printf("\nAverage of roots: %lf\n", answer);
}
